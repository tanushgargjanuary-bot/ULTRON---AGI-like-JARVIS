# Ordered remaining work

Start with the red CI. Do not begin feature expansion until its precise failure is understood.

## P0 — Diagnose latest red CI on current HEAD

**Latest observed run:** `42529553481` (triggered after artifact commit `b2b9bbd`; see current PR checks for any later run). Earlier run `42526114356` on `da01db7` also failed.

1. Open the GitHub Actions run from `GITHUB_STATUS.md` in a browser with access to its logs/artifacts.
2. Read the complete Linux and Windows failed-step output. Do not infer from generic annotations or “needs a package that is not installed.”
3. Reproduce the exact failing step locally if possible (or use the runner artifact/report); identify whether this is a test regression, verifier/tooling issue, optional dependency gap, or Windows-native limitation.
4. Make the smallest verified fix; add a focused test if it is code behavior. Keep the cause and evidence in the project record.
5. Push to the existing session branch only. Wait for both CI jobs. Do not call this branch green until both succeed.

The sandbox could query job/check metadata but could not read logs: logs redirected to `results-receiver.actions.githubusercontent.com`, artifacts to `productionresultssa32.blob.core.windows.net`, neither allowed from that sandbox. Do not keep retrying those same blocked endpoints there.

## P1 — Plan persistence / hard-kill acceptance (issue #11)

The code has plan checkpoint/resume machinery, but the specific crash/restart acceptance is not complete. The issue asks for a process-kill test between step 2 and 3, resume at step 3, re-confirm an unconfirmed write, stale-checkpoint behavior, and an overall green suite.

The PR #12 review has additional plan-state concerns to verify against current code, especially:

- Reject nonnumeric and non-finite checkpoint indices/timestamps before startup.
- Do not resume a write that references step output absent from the checkpoint; either safely reconstruct or block.
- Bind a saved plan to its original workspace and reject a mismatched workspace.
- Do not persist preview-only plans over an interrupted active plan.
- If a checkpoint update fails after a side effect, invalidate/mark it unsafe so restart cannot repeat a non-idempotent action.
- Make discard clear the checkpoint; test that behavior.
- Re-run confirmation for each not-yet-confirmed step after resume and test that per-step approval survives reload appropriately.

Do not persist API keys, passwords, screen captures, or private model outputs. Test with a subprocess that is actually killed, not just a simulated return or a manually written state file.

## P1 — Resolve PR review and branch scope

PR #12 is named “plan: a plan survives a restart, and says so in one line (#11)” but contains broad work from multiple changes. Its review history flagged out-of-scope changes and requested a reduced PR containing only plan persistence files; it also has many CodeRabbit comments from an older diff. The owner has said not to merge and not to modify `main`.

- Read CodeRabbit comments against the current code; the review was submitted against commit `657b73bc...`, not current `da01db7`.
- Kilo review is `ACTION_REQUIRED`; in earlier context it was blocked by account credits.
- Decide with the owner whether to split/reduce this PR or keep it. Do not silently close/merge PRs or delete branch work.

## P1 — Exhaustive undo/refusal audit (issue #5)

The issue's acceptance is stronger than current code:

- Enumerate every action/tool operation that mutates files, config, memory, OS settings, browser state, scheduled tasks, devices, or remote accounts.
- For every operation, write an integration test that performs it, calls undo, then compares original bytes/state where a reverse is possible.
- For actions that cannot be undone (sent messages, remote API mutations, clipboard replacement, external installs, some OS effects), explicitly name and list them. They must not be presented as reversible.
- Add a test that a mutating tool with no valid undo is refused/blocked instead of silently executing, while preserving the existing policy and confirmation contract.
- Report a reviewed count: reversible writers with proven undo / total reversible writers, separately from irreversible writers. Do not count imports, helpers, logs, caches, or source files by module presence alone.

Current partial coverage: `actions/file_processor.py` generated text outputs only, with bounded snapshots, conflict detection, and rollback if undo registration fails. Binary conversions, video/audio outputs, archive extraction, and other tool writers are not covered by that helper. `core.undo.push_undo()` returning a boolean is a supporting change, not proof of universal undo.

Potential writer modules to audit (heuristic list, not final count): `background_monitor`, `browser_control`, `code_helper`, `computer_control`, `computer_settings`, `desktop`, `dev_agent`, `file_controller`, `file_processor`, `flight_finder`, `game_updater`, `reminder`, `screen_processor`, `self_change`, `youtube_video`; also inspect messaging/browser/network/device side effects.

Constraint: do not edit `core/confirm.py` without explicit owner authorization.

## P2 — Close OCR acceptance (issue #4) safely

- Install optional `pytesseract` plus native Tesseract on a test machine; run the known-text fixture recognition test rather than accepting its current skip.
- Confirm OCR is selected before remote vision for text-read requests, remains local/no-upload, and cannot perform click/control actions.
- Measure actual screenshot accuracy at the owner's DPI, font sizes, and dark mode on his Windows device. Do not duplicate code from the private `antigravity` work.

## P2 — Owner's actual desktop/device proof (issue #6)

A CI Windows runner is not an interactive desktop. The owner or a trusted operator must run on the actual Windows PC:

```powershell
python scripts\verify.py
python scripts\proof_gate.py
python scripts\verify_all.py
```

Then record the exact PROVEN/PARTIAL/FAILED counts, and any flipped claims, in issue #6. Also launch the GUI and manually verify persona/theme/voice switching, context continuity, accessibility tree, OCR behavior, microphone/camera consent, and stop controls as feasible. No claims about that machine until the evidence exists.

## P2 — Updater and safe release path

There is existing updater/self-update code (`custom_jarvis/selfupdate.py`, `core/leaf_generations.py`), but do not mistake that for a complete production updater. Identify remaining acceptance with the owner, then implement and test as separate slices: signed release manifest verification, version/compatibility checks, staging, atomic activation or A/B install, rollback on a bad launch, no loss of user data, and owner-visible restart requirements. Test power-loss/kill at each state boundary. Avoid auto-download/install or elevated changes without approval.

## P3 — Routing/OCR issue closure and Rust decision

- Issue #3 routing is now wired and has local tests including the new pipeline voice-switch integration test. It still needs current full CI green and review before issue closure; do not claim owner-key cost/quality tests.
- Issue #10 MCP implementation and selected proof checks exist in the repo, but issue remains open. Recheck issue acceptance and current CI/reviewer status before closing.
- Issue #9 grant-expiry fix is committed in the branch history and the focused proof gate passed. It remains open on GitHub; close only after owner/review/CI rules are satisfied.
- The Rust evaluation does not justify a rewrite. Do not spend more time on Rust unless a measured production profile shows a meaningful bottleneck.

## Scope exclusions

- Do not inspect or work in the private owner-development repo.
- Do not merge PR #12 or #8, switch/rename the active Arena branch, or change `main` without explicit authorization.
- Do not mark owner-only/Windows-only evidence complete from Linux CI.
