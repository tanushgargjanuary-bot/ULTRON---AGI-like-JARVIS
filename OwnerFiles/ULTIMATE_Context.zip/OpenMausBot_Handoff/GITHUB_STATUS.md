# GitHub state at handoff

## Branch and commits

The live checkout and PR use lowercase suffix `arena/4c973188-ultron-agi-like-jarvis`. Current snapshot HEAD is `da01db7bf66c682af79c5b945ba55325545d3bfe`; parent `576f9b412e5089522f80252d0be2abb33e15f4c9`. It is pushed to `origin` and clean at snapshot time. Do not create a similarly named uppercase branch; Git ref names are case-sensitive.

## Pull requests

- **PR #12** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/pull/12
  - State: **OPEN**.
  - Title: “plan: a plan survives a restart, and says so in one line (#11)”.
  - Head: `arena/4c973188-ultron-agi-like-jarvis` at `da01db7`.
  - Base: `ArenaAi` (not `main`).
  - Latest workflow run `42526114356` is **FAILURE on Linux and Windows**. This is the main immediate blocker.
  - Kilo Code Review: `ACTION_REQUIRED`; earlier handover says it was blocked by account credits. Recheck its current detail.
  - CodeRabbit: a large earlier review was submitted against commit `657b73bc84c9a0968207432cc8be0ff7437a2318`, not the current head. It reported 23 actionable comments (10 major, others lower severity), and CodeRabbit on the latest run was skipped. Verify each comment against current code; do not blindly follow generated text.
  - Earlier CodeRabbit failed checks included PR scope/out-of-scope findings, linked-issue acceptance, and docstring coverage. It asked for explicit discard, approval-on-resume tests, checkpointed confirmation, and running `python scripts/verify.py` on a reduced PR. Owner must decide whether to reduce/split; do not silently alter PR structure.
- **PR #8** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/pull/8
  - State: **OPEN** at last queried status.
  - Title: “main is red: carry the green branch's instruments onto it”.
  - Head `ArenaAi` → base `main`.
  - Do not merge or edit `main`; recheck before making any claim about current status.

## Open issues relevant to remaining work

- **#3 Routing integration** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/3. Implementation and focused tests now exist; still needs current CI green/review. Its old body mentions nonexistent `core/intent_router.py`; do not chase that path.
- **#4 Local OCR rung** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/4. Code and mocked/ladder tests exist; real Tesseract fixture and owner's screen accuracy remain unverified.
- **#5 Undo every writer** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/5. Incomplete. It explicitly requires a per-writer integration test, refusal for writes without undo, and honest reversible/irreversible counts.
- **#6 Owner's Windows proof** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/6. Owner-machine run required; CI does not satisfy it.
- **#9 Grant expiry** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/9. The fix and focused proof exist in branch history, but issue remains open. It was originally marked referee-sensitive; any further policy edits need explicit authorization.
- **#10 MCP client** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/10. The repo already has an implementation and proof-gate coverage, but issue remains open; validate current acceptance/CI before closing.
- **#11 Plan survives restart/crash** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/11. Code exists, but hard-kill/resume acceptance and review concerns remain.
- **#7 Agent coordination** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/7. Use `claim: <branch> <what> <files> — <agent>` before parallel work and `released: <branch> <commit>` before push.
- **#2 Notion handover conventions** — https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/issues/2. Existing convention: one page per project, current facts first, exact counts, update rather than append, link files, preserve other agents' work.

## Do not infer

The current PR is open, but its CI is failed. Older green runs (`42519896932` on `576f9b4` and earlier historical runs) do not prove current HEAD. The current branch is not merged. No new code was pushed to `main` by this work.
