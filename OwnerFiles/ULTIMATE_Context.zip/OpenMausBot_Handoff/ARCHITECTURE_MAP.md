# Architecture and current feature map

This is a large Python/PyQt6 voice assistant. Read `project/ARCHITECTURE.md`, `project/AGENTS.md`, `project/WORKING-PHILOSOPHY.md`, and `project/docs/MAP.md` for the repository's deeper design. This map highlights the current conversation slice and likely next work.

## Main paths

- `main.py` — application boot/session wiring; avoid importing it in tests because it can start GUI/crash-hook side effects. Current routing and persona/context setup are wired here.
- `ui.py` — PyQt6 HUD, persona/theme selection, and rebuild callbacks. Qt is not installed in the handoff sandbox, so the new UI was compile-checked and unit-tested indirectly, not launched.
- `providers/engine_pipeline.py` — alternate STT/LLM/TTS pipeline. It recognizes the supported provider-switch utterance before normal LLM generation, adds the switch request/response to conversation history, and emits the acknowledgement.
- `core/routing.py` — provider/model routing primitives and usage ledger.
- `core/routing_runtime.py` — adapts route purposes (`conversation`, `evolution`, `critic`) to configured clients; provides selection/logging/usage accounting and local spoken-switch parsing.
- `core/personas.py` — five requested personas and their prompt/voice/animation metadata.
- `core/conversation_context.py` — transcript/context carry-over when a provider, voice, or persona rebuild creates a fresh engine/session.
- `core/avatar.py` — face/avatar rendering and persona-specific animation selection.
- `core/themes.py` — theme presets and helpers. Theme and persona settings are separate.
- `core/local_ocr.py` — bounded local OCR adapter. Requires Pillow, pytesseract, and native Tesseract; no upload path.
- `core/ui_ladder.py` — prefers accessibility structure, then local OCR for explicit text-reading requests, then configured vision/ask fallback. OCR is text extraction only.
- `actions/ui_control.py` — UI control tool dispatch including OCR and availability reporting.
- `core/policy.py` — tool risk/approval classifications. OCR is a sensor operation. Treat this and `core/confirm.py` as referee code; do not modify without explicit authorization.
- `core/undo.py` — shared bounded undo stack (`MAX_DEPTH=10`); `push_undo` now returns success/failure.
- `actions/file_processor.py` — generated text-output helper captures prior bytes up to 1 MiB, registers a conflict-aware undo, and rolls back if registration fails. Many non-text outputs still bypass this helper.
- `custom_jarvis/plan_state.py`, `custom_jarvis/planner.py`, `custom_jarvis/service.py` — existing persisted plan/checkpoint and resume logic. Review against issue #11 and current review comments; do not assume “checkpoint exists” proves hard-kill-safe behavior.
- `custom_jarvis/selfupdate.py`, `core/leaf_generations.py` — existing updater/leaf-generation mechanisms. Their existence does not prove signed updater, A/B installer, or all rollback acceptance is complete.
- `scripts/proof_gate.py`, `scripts/verify.py`, `scripts/verify_all.py` — different evidence instruments. Read their outputs; do not conflate them.

## Routing test flow just added

`tests/test_routing_runtime.py::test_pipeline_intercepts_voice_route_switch_without_dropping_history` feeds fake speech through `PipelineEngine.flush_microphone()`. It starts with prior turns; asserts the incoming transcription, the local Ollama-switch acknowledgement, full old/new history, persisted provider setting, and empty usage ledger (a switch should not spend an LLM request). The shared capability test immediately follows this test.

## New persona design intent

- Ultron: normal.
- Nova: Teenager.
- Cipher: Hacker.
- Vanta: Villain.
- Luna: Girly.

Persona changes may affect system prompt style and face animation. They must not change tool catalogue, policy tiers, approvals, or assistant capabilities. Persona/theme/voice can be mixed independently. The user specifically wants context to survive changes and distinct face animation sets per persona.

## Known implementation boundary: undo

The new text helper is not a system-wide writer wrapper. Known writer candidates from an earlier AST scan include `background_monitor`, `browser_control`, `code_helper`, `computer_control`, `computer_settings`, `desktop`, `dev_agent`, `file_controller`, `file_processor`, `flight_finder`, `game_updater`, `reminder`, `screen_processor`, `self_change`, and `youtube_video`. Some are false positives or helper/cache writes; some effects are external and cannot be undone. The inventory has not been manually validated, and the list is not an exhaustive audit. Inspect each tool/action branch and every file/network/device mutation before reporting counts.
