# OpenMausBot handoff — Ultron / ULTRON---AGI-like-JARVIS

This handoff is for the next agent taking over the Ultron repository in OpenMausBot. It contains a source snapshot of the exact committed tree plus the current state, owner preferences, decisions, validation evidence, and an ordered backlog. It intentionally excludes `.git`, credentials, runtime state, and private owner-development repositories.

## One-minute state

- Repository: `https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS`
- Active session branch: `arena/4c973188-ultron-agi-like-jarvis` (lowercase suffix, confirmed by `git branch --show-current` and PR #12)
- Snapshot commit: `da01db7bf66c682af79c5b945ba55325545d3bfe`
- PR #12: open, branch → `ArenaAi`; **latest CI is red on both Linux and Windows**. Do not call the branch green.
- PR #8 (`ArenaAi` → `main`) is also open. User's standing instruction: **do not merge and do not modify `main`.**
- Latest local focused verification: **102 passed, 1 skipped**. Selected policy/MCP proof-gate claims: PROVEN. These do not override the latest red CI.
- Immediate priority: retrieve and diagnose GitHub Actions run **42526114356** from its GitHub UI. This sandbox could see the failure summaries but could not download logs because GitHub redirects logs/artifacts to hosts outside its network allowlist.

## Start here

1. Read `CURRENT_STATE.md`, then `OWNER_PREFERENCES.md`, `BACKLOG.md`, and `VALIDATION.md`.
2. In the live repo, inspect `git status --short -b`, `git log -5 --oneline`, and the current PR/CI before editing. This bundle is a snapshot, not a replacement for live Git state.
3. Open `https://github.com/tanushgargjanuary-bot/ULTRON---AGI-like-JARVIS/actions/runs/42526114356` and inspect both failed jobs. The failing steps are Linux **“Suite, self-checks, migration and mutation gates”** and Windows **“Native checks.”** Identify the exact failure before changing code.
4. Use one agent to own any shared files. Delegate read-only audits or independent tests to other agents. Do not have multiple agents edit `main.py`, `ui.py`, `core/policy.py`, or the same tests simultaneously.

## Contents

- `CURRENT_STATE.md` — exact current facts and what is incomplete.
- `OWNER_PREFERENCES.md` — how the owner wants work done and explicit constraints.
- `DECISIONS_AND_HISTORY.md` — journey, key reasoning, decisions, and failed approaches.
- `ARCHITECTURE_MAP.md` — relevant modules and how the new work is connected.
- `BACKLOG.md` — ordered next steps and acceptance criteria.
- `VALIDATION.md` — exact test commands/results and environment limits.
- `GITHUB_STATUS.md` — current PRs, issues, CI run, and reviewer state.
- `project/` — tracked source tree exported from commit `da01db7`; no `.git` directory.

## Important wording rule

Separate **implemented**, **tested locally**, **passed in CI**, and **verified on the owner's actual Windows desktop/device**. Those are different levels of evidence. This project has repeatedly lost time when they were blurred.
