# Decisions, reasoning, journey, and known dead ends

## The project's central rule

Ultron began as a working Windows voice assistant based on FatihMakes/Mark-LVI (CC BY-NC 4.0). The aim is not to claim “AGI”; it is to make a useful assistant more trustworthy. The recurring rule is: **a claim needs evidence; if evidence is missing, say so.** The proof gate, safety tiers, refusal behavior, and careful handover practices all follow from this.

## Decisions that remain active

- **Persona is presentation, not permission.** Persona-specific prompts/face animation must not add tools, raise permissions, weaken approvals, or change the safety referee.
- **Mix-and-match UI.** Persona, theme, and voice are separate preferences. A one-click combo is convenient, but users can change one axis independently. Keep history when a session is rebuilt.
- **Local OCR is an optional low rung.** Read the screen locally for text before paying for or sending pixels to vision. If the local dependency is unavailable, say so/fall through as designed. OCR is not a click tool and must not upload a screenshot.
- **Routing does not silently invent fallbacks.** Route purposes to configured providers/models; log what was chosen. Hosted services may cost money; local services remain local. A supported spoken conversation-provider switch is explicit and persisted. Ambiguous local model requests should ask for a name.
- **Undo is safer than confirmation spam, but only when it is real.** For each writer, either implement and prove a correct reverse, or classify the effect as irreversible/refuse or explicitly request approval according to policy. Do not fake an undo or call module-level `push_undo` presence proof of full coverage.
- **Keep Python unless measured otherwise.** The synthetic fuzzy benchmark does not establish a Rust bottleneck. Application latency is dominated by model/network/device work, not a few hundred microseconds of Python matching.
- **Plan persistence is not the same as crash safety.** A checkpoint file can exist yet be malformed, stale, bound to the wrong workspace, missing a step output, or unsafe to resume. Hard-kill and resume approval must be tested as behavior, not inferred from file existence.
- **The user wants multiple agents if possible.** Arena could not spawn agents; OpenMausBot can. Use parallel read-only investigation, then a single integrator for shared files.

## Recent journey, in order

1. **Trust and policy fixes.** Prior work fixed grant expiry/tier isolation in `core/policy.py`, added tests, and established proof-gate checks. Commit `576f9b4` is the parent of the current feature commit. Earlier commit `54a76db` is also in the branch history.
2. **MCP and plan work.** Earlier branch work added local MCP client lifecycle and safer plan persistence/resume. Issue #10 and #11 remain open despite substantial code, because acceptance/review/proof is unfinished. PR #12 carries this broader history and currently targets `ArenaAi`.
3. **Generation reload / self-update work.** Existing docs under `OwnerFiles/` describe staged action/plugin generations, reconnect-safe reload, and self-update. Do not assume these solve every updater or worker/supervisor requirement; inspect current code and review comments.
4. **Current feature slice (`da01db7`).** Added persona/context continuity, OCR rung, live routing adapter/wiring, spoken route switching, a pipeline integration test, and partial undo support for generated text outputs.
5. **Current CI regression.** The new commit was pushed and PR #12 CI run `42526114356` failed Linux suite/self-checks and Windows native checks. The logs could not be downloaded from this sandbox due blocked redirect hosts. This is now the first task, before adding more features.

## Historical failures and traps already recorded in the repo

- A malformed tool declaration once caused a provider to reject the entire tool list and the assistant blamed an API key; maintain schema sanitization/tests.
- A close code is not a diagnosis. Read the message and classify schema/key/quota/model/network separately.
- Tests that import `main.py` can start the GUI or install crash hooks; prefer narrow modules and inspect existing tests first.
- CRLF changes in Windows-first files can turn a small edit into a whole-file diff.
- Do not infer a clean state from a green process exit alone; inspect results/artifacts.
- The Windows UI Automation bridge and physical desktop path require real Windows/interactive-machine proof.
- Existing handover docs can be stale. `OwnerFiles/for-the-next-agent.md` and `HANDOFF.md` include earlier commit/test/CI snapshots; their useful lessons remain, but their “current” facts have been superseded. Update them carefully.

## Selective Rust measurement

Prior synthetic benchmark: `python scripts/bench_algorithms.py --only fuzzy --json` reported top-1 accuracy `1.0` on 15 test cases at approximately `341.8 μs/query` across 600 candidates. This is not a production workload, not a user-facing latency test, and not evidence that Rust would improve end-to-end performance. Keep the implementation in Python until a real profile demonstrates a material bottleneck.

## Source/licensing note

The repository's upstream base is attributed in its existing docs as FatihMakes/Mark-LVI, CC BY-NC 4.0. Preserve that attribution/licence. Do not vendor third-party code or models without reviewing licence/security and asking before heavyweight downloads.
